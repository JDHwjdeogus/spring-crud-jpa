package com.dw.springcrudjpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCrudJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCrudJpaApplication.class, args);
	}

}
