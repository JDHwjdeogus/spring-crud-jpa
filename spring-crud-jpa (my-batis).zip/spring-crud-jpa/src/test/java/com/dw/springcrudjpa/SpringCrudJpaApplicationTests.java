package com.dw.springcrudjpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCrudJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
